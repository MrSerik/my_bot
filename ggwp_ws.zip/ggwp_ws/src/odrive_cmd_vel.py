import odrive
from odrive.enums import *

# Подключение к ODrive
print("Connecting to ODrive...")
odrv0 = odrive.find_any()

# Настройка режимов управления
odrv0.axis0.controller.config.control_mode = CONTROL_MODE_VELOCITY_CONTROL
odrv0.axis1.controller.config.control_mode = CONTROL_MODE_VELOCITY_CONTROL

odrv0.axis0.requested_state = AXIS_STATE_CLOSED_LOOP_CONTROL
odrv0.axis1.requested_state = AXIS_STATE_CLOSED_LOOP_CONTROL

odrv0.axis0.controller.input_vel = 0
odrv0.axis1.controller.input_vel = 0

odrv0.axis0.controller.config.vel_limit = 1
odrv0.axis1.controller.config.vel_limit = 1

c = 0.5  # Скорость движения

def control_loop():
    print("Control started. Type commands to control the motors:")
    print("""
    Available commands:
        1 CW  - Axis 0 clockwise
        1 CCW - Axis 0 counterclockwise
        1 ST  - Axis 0 stop
        2 CW  - Axis 1 clockwise
        2 CCW - Axis 1 counterclockwise
        2 ST  - Axis 1 stop
        EXIT  - Exit the program
    """)
    while True:
        command = input("Enter command: ").strip().upper()
        
        if command == "1 CW":
            print("Axis 0 CW")
            odrv0.axis0.controller.input_vel = c
        elif command == "1 CCW":
            print("Axis 0 CCW")
            odrv0.axis0.controller.input_vel = -c
        elif command == "1 ST":
            print("Axis 0 STOP")
            odrv0.axis0.controller.input_vel = 0
        elif command == "2 CW":
            print("Axis 1 CW")
            odrv0.axis1.controller.input_vel = c
        elif command == "2 CCW":
            print("Axis 1 CCW")
            odrv0.axis1.controller.input_vel = -c
        elif command == "2 ST":
            print("Axis 1 STOP")
            odrv0.axis1.controller.input_vel = 0
        elif command == "EXIT":
            print("Exiting...")
            break
        else:
            print("Unknown command. Try again.")

# Запуск основного цикла
if __name__ == "__main__":
    control_loop()
